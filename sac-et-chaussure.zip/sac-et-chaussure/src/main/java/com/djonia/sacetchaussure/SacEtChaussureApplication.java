package com.djonia.sacetchaussure;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SacEtChaussureApplication {

	public static void main(String[] args) {
		SpringApplication.run(SacEtChaussureApplication.class, args);
	}

}
