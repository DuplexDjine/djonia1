package com.djonia.sacetchaussure;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SacEtChaussureApplicationTests {

	@Test
	void contextLoads() {
	}

}
